import React from 'react'

export default function Courses() {
  return (
    <div className='courses d-flex align-items-center justify-content-center'>
        <h1>Welcome to Courses Page</h1>
    </div>

  )
}
